a = 5
b = 20
result = int (a*b)
print(result)